# Pokémon Collection — app solo per iPad

Gira interamente sull'iPad: fotocamera, riconoscimento della carta (OCR incluso nell'app, funziona anche offline),
database delle carte che possiedi e storico dei valori. Nessun PC, nessun server tuo, nessun costo.

## Come si usa
- **Scansiona**: inquadra la carta nel riquadro e tocca «Scatta e riconosci». Vedi nome, collezione, numero, tipo, PS e prezzo.
  Il flag «Ce l'ho nella mia raccolta» si barra da solo se il riconoscimento è sicuro (lo puoi togliere; c'è anche la quantità).
  Se non è sicuro non barra nulla e ti propone altre carte; puoi anche cercare per nome o usare una foto già scattata.
- **Raccolta**: le carte che possiedi, valore totale, variazione e, toccando una carta, grafico e tabella dello storico.
- **Aggiorna valore collezione**: pulsante manuale. Ogni pressione legge i prezzi attuali, aggiorna il totale e aggiunge un
  punto allo storico di ogni carta. Non c'è nessun aggiornamento automatico.
- **Impostazioni**: token CardTrader, condizione/lingua/valuta del prezzo, scarico del catalogo, backup.

## Installazione gratuita (circa 15 minuti, tutto da iPad)
L'app è un sito che installi sulla schermata Home. Serve un posto gratuito dove pubblicarlo: GitHub Pages.
1. Apri il file `pokemon-ipad.zip` nell'app File: si crea la cartella con dentro `sito`.
2. Da Safari crea un account gratuito su **github.com**.
3. Crea un nuovo repository: nome a piacere (es. `pokemon`), visibilità **Public**, poi *Create repository*.
4. Nella pagina del repository scegli **uploading an existing file** e carica **tutti i file** della cartella `sito`
   (12 file: selezionali insieme dall'app File). Poi *Commit changes*.
   Il repository è pubblico ma contiene solo il codice dell'app: i tuoi dati e il token restano solo sull'iPad.
5. *Settings → Pages → Build and deployment*: Source = **Deploy from a branch**, Branch = **main** e cartella **/(root)** → *Save*.
   Dopo 1-2 minuti compare l'indirizzo `https://<tuo-utente>.github.io/<nome-repo>/`.
6. Aprilo con Safari sull'iPad, consenti la **fotocamera**, poi Condividi → **Aggiungi alla schermata Home**.
7. Apri l'app dall'icona → **Impostazioni** → incolla il **token API di CardTrader** (nel tuo profilo CardTrader, impostazioni
   per sviluppatori) → *Salva* → *Prova collegamento*.
8. Premi **Scarica / aggiorna catalogo**: la prima volta richiede alcuni minuti, tieni l'iPad acceso e l'app aperta.
   Se si interrompe, ripremi: riparte da dove era arrivato.

## Se «Prova collegamento» dice che il browser non riesce a parlare con CardTrader
Non ho potuto verificare se CardTrader accetta chiamate dirette da un browser (blocco di sicurezza chiamato CORS).
Se la prova fallisce con quel messaggio serve un piccolo «ponte» gratuito (Cloudflare Workers, piano gratuito):
1. Crea un account gratuito su **cloudflare.com** → *Workers & Pages* → *Create* → *Hello World* → *Deploy*.
2. *Edit code*: cancella tutto, incolla il contenuto di `proxy-cloudflare.js` → *Deploy*.
3. Copia l'indirizzo che finisce con `.workers.dev` e incollalo in Impostazioni → «Indirizzo del proxy» → *Salva* → *Prova collegamento*.
Il ponte inoltra soltanto le richieste a CardTrader e non salva nulla.

## Backup (importante)
I dati stanno solo sull'iPad. In Impostazioni → **Salva backup** crea un file da mettere in File/iCloud Drive;
**Ripristina backup** lo rimette (anche su un altro iPad). **Esporta in Excel (CSV)** dà l'elenco leggibile in Excel/Numbers.
Non cancellare i dati di Safari/siti web e non rimuovere l'app senza aver fatto un backup.

## Prezzi
Valore = prezzo più basso in vendita su CardTrader (Near Mint, in euro se disponibile, esclusi venditori in vacanza e carte gradate),
tramite l'API ufficiale. Non è un prezzo medio di mercato. Condizione, lingua e valuta si cambiano in Impostazioni.

## Limiti da conoscere
- Se CardTrader non fornisce PS, tipo o rarità, l'app prova a completarli dal sito pokemontcg.io quando aggiungi la carta;
  se non li trova restano «—».
- Il riconoscimento legge nome e numero stampati: foto nitide, luce uniforme, carta intera nel riquadro. Con carte in italiano
  il nome può differire dal catalogo: conta soprattutto numero + collezione.
- Per i prezzi e l'aggiornamento del catalogo serve internet; scansione e consultazione della raccolta funzionano anche offline.
- Non è un'app dell'App Store: è una web app sulla schermata Home. Per aggiornarla in futuro basta ricaricare i file su GitHub.
