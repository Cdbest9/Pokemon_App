// Proxy gratuito per CardTrader (Cloudflare Workers, piano gratuito).
// Serve solo se il collegamento diretto dal browser viene bloccato (CORS).
// Inoltra le richieste a CardTrader usando il token che l'app invia; non conserva nulla.
const TARGET = "https://api.cardtrader.com/api/v2";
const CORS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "Authorization, Content-Type",
  "Access-Control-Allow-Methods": "GET, OPTIONS",
};
export default {
  async fetch(request) {
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: CORS });
    if (request.method !== "GET") return new Response("Method not allowed", { status: 405, headers: CORS });
    const url = new URL(request.url);
    const auth = request.headers.get("Authorization");
    if (!auth) return new Response("Missing token", { status: 401, headers: CORS });
    const upstream = await fetch(TARGET + url.pathname + url.search, { headers: { Authorization: auth, Accept: "application/json" } });
    const headers = new Headers(CORS);
    headers.set("Content-Type", upstream.headers.get("Content-Type") || "application/json");
    return new Response(upstream.body, { status: upstream.status, headers });
  },
};
